# GAACE Licensing Kit

Ready-to-use licensing files for the GAA Custom Electronics repositories. The decisions are made — this is a copy-and-fill exercise, not a set of options.

| Asset type | License | SPDX identifier |
|---|---|---|
| Hardware design files | CERN Open Hardware Licence v2 — Weakly Reciprocal | `CERN-OHL-W-2.0` |
| Firmware (runs on GAACE boards) | MIT License | `MIT` |
| Host application / portable software | GNU General Public License v3.0 or later | `GPL-3.0-or-later` |
| Documentation and manuals | Creative Commons Attribution 4.0 International | `CC-BY-4.0` |

**Why firmware and the host app differ.** Firmware only runs on GAACE hardware — nobody forks it to compete, because they'd need the board — so reciprocity buys little, and MIT keeps it compatible with the mostly-MIT/LGPL Arduino/ARM library ecosystem. The host application is portable and is where a closed fork could actually matter, so it stays copyleft under GPL-3.0. This split is what most open-hardware companies land on.

**Not legal advice.** Worth thirty minutes with an attorney before the first release — particularly the Qt question in the pre-publish checklist.

---

## What's in here

```
gaace-licensing-kit/
├── README-FIRST.md                    ← you are here
│
├── hardware-repo/                     ← copy all of this into a hardware repo
│     ├── LICENSE                      CERN-OHL-W-2.0, full text, unmodified
│     ├── LICENSE-DOCS                 CC-BY-4.0, full text, unmodified
│     ├── README.md                    template — fill in the <placeholders>
│     └── CONTRIBUTING.md              ready to use as-is
│
├── firmware-repo/                     ← firmware that runs on GAACE boards
│     ├── LICENSE                      MIT, copyright filled in
│     ├── README.md                    template — fill in the <placeholders>
│     └── CONTRIBUTING.md              ready to use as-is
│
├── hostapp-repo/                      ← portable host software (e.g. MIPS_QT6)
│     ├── LICENSE                      GPL-3.0-or-later, full text, unmodified
│     ├── README.md                    template — fill in the <placeholders>
│     └── CONTRIBUTING.md              ready to use as-is
│
├── profile-repo/
│     └── README.md                    → GordonAnderson/GordonAnderson
│
├── licensing-repo/                    ← optional canonical policy repo
│     └── README.md                    → GordonAnderson/licensing
│
└── reference/
      ├── SOURCE-LOCATION-NOTICE.txt   CERN-OHL requirement — what to put on boards
      ├── SPDX-HEADERS.txt             file header snippets for source and CAD
      ├── EXAMPLE-kf-feedthroughs-README.md   a filled-in hardware README
      ├── PRE-PUBLISH-CHECKLIST.md     read before the first repo goes public
      └── CC-BY-4.0-fulltext.txt       spare copy
```

License texts are verbatim from the SPDX license list. **Do not edit them** — a modified license is no longer the license it claims to be, and tooling that checks SPDX identifiers will flag the mismatch.

---

## Setting up a hardware repository

1. Create the repo, public
2. Copy the entire contents of `hardware-repo/` into the root
3. Open `README.md` and fill in every `<placeholder>` — there are about eight
4. Commit design files under `hardware/`, documentation under `docs/`
5. Add the Source Location notice to your schematic title block and silkscreen — see `reference/SOURCE-LOCATION-NOTICE.txt`

`reference/EXAMPLE-kf-feedthroughs-README.md` shows a completed one.

## Setting up a firmware repository (MIT)

1. Copy the contents of `firmware-repo/` into the root
2. Fill in the `<placeholders>` in `README.md`
3. In "Third-party components," watch for any GPL-licensed library — MIT is compatible with permissive licenses, but a GPL dependency imposes copyleft on the combined work.
4. Add SPDX headers to source files — see `reference/SPDX-HEADERS.txt`

## Setting up the host-application repository (GPL-3.0)

1. Copy the contents of `hostapp-repo/` into the root
2. Fill in the `<placeholders>` in `README.md`
3. **Complete the "Third-party components" section.** If the app links against open-source Qt, that is LGPLv3 and carries relinkability obligations — state it explicitly. This is the item an institution's legal office is most likely to ask about.
4. Add SPDX headers to source files — see `reference/SPDX-HEADERS.txt`

## Setting up the profile README

Create a public repo named exactly `GordonAnderson` (matching your username), and put `profile-repo/README.md` in it as `README.md`. It renders at the top of `github.com/GordonAnderson`.

This is your "unless otherwise noted" umbrella statement. It's useful as an explanation but is **not** a substitute for per-repo LICENSE files — GitHub cannot apply a default license across an account, and default files aren't included when a repo is cloned or downloaded.

## Optional: the licensing repo

If you'd rather each README link to one canonical policy than restate it, create `GordonAnderson/licensing` and use `licensing-repo/README.md`.

---

## Filename note

The `LICENSE` files here have no extension, matching repository convention. GitHub's license detection also accepts `LICENSE.txt` and `LICENSE.md` — use whichever you prefer.

GitHub reads only the **root** `LICENSE` for its license badge. It will not detect `LICENSE-DOCS`. That's expected: root holds the dominant license, and the README explains the exception.

GitHub may not offer CERN-OHL in its license picker. The file still works, and the SPDX identifier in your README is what automated tooling reads.

---

## In plain terms — what these licenses do

**CERN-OHL-W (hardware).** Anyone may study, modify, manufacture, and distribute your designs, including commercially. If they distribute a product based on a *modified* version of your design, they must publish their modified design files under the same license. Changes to the surrounding product — an instrument your board is embedded in — do **not** have to be published. That's the "weakly" part, and it's what keeps the door open for OEM customers like Bruker, Thermo, and Agilent.

**MIT (firmware).** Anyone may use, modify, and redistribute — including in closed products — as long as they keep the copyright notice. No obligation to publish changes. Chosen because firmware only runs on GAACE hardware, so copyleft protection buys little, and MIT avoids library-compatibility friction.

**GPL-3.0-or-later (host application).** Anyone may use, study, modify, and redistribute. Distributing a modified version requires publishing source under the same license. Chosen because the host app is portable — this is where a closed competing fork could actually matter.

**CC-BY-4.0 (docs).** Free to use and adapt with attribution.

**Trademarks are separate and are not licensed by any of the above.** This is the mechanism that actually protects you: someone may build your board from published Gerbers, but they may not call it a MIPS module or a GAACE product. Every template in this kit states this explicitly.

---

## A note on future flexibility

Right now GAACE owns 100% of the copyright in these designs, which means you can relicense or dual-license them freely at any time. That changes the moment you merge someone else's pull request — from then on, relicensing needs every contributor's permission.

The `CONTRIBUTING.md` files in this kit handle that in two ways:

- **A forward-license grant.** Contributors agree their work may be distributed under the project's current license *or any later license the project adopts*. This is much lighter than a full CLA, and covers the realistic case — you can move to a newer license version later without tracking anyone down.
- **DCO sign-off.** Contributors add `Signed-off-by:` to commits, certifying they have the right to submit. No forms or accounts, and it establishes clean provenance.

Both are already written into the templates. Nothing to configure.

Two things worth knowing about changing your mind later:

- **You can always relicense going forward.** Rev B can ship under different terms; you can dual-license commercially; you can stop publishing entirely.
- **You cannot revoke what's already granted.** Anyone who downloaded Rev A under CERN-OHL-W keeps those rights to that version permanently. Deleting a repository doesn't undo it — clones and forks persist. In practice this matters less than it sounds, since hardware moves forward and an old revision has limited value to anyone.

---

## Read before the first release

`reference/PRE-PUBLISH-CHECKLIST.md`. Two items on it are genuinely blocking rather than nice-to-have:

- **Customer-funded designs may not be yours to publish.** Your rate sheet already distinguishes GAACE-funded from customer-funded work. Apply that line before a repo goes public.
- **The rate sheet contradicts the website.** `RateSheet03292026.docx` says product IP cannot be "duplicated, transferred and/or re-sold." That can't coexist with an open hardware license. Scope the clause to customer-funded proprietary work, or update it.
