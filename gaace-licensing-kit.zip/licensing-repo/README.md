# Licensing Policy — GAA Custom Electronics, LLC

Canonical licensing statement for all GAACE repositories. Individual repositories may state different terms; **where they do, the repository's own `LICENSE` file governs.**

Last updated: July 2026

---

## Defaults

| Asset type | License | SPDX identifier |
|---|---|---|
| Hardware design files — schematics, PCB layout, Gerbers, BOM, mechanical | CERN Open Hardware Licence Version 2 — Weakly Reciprocal | `CERN-OHL-W-2.0` |
| Firmware (runs on GAACE hardware) | MIT License | `MIT` |
| Host application / portable software | GNU General Public License v3.0 or later | `GPL-3.0-or-later` |
| Documentation, manuals, application notes | Creative Commons Attribution 4.0 International | `CC-BY-4.0` |

## What this permits

You may, without asking permission and without cost:

- Study the designs and source
- Modify them for any purpose
- Manufacture boards, in any quantity, for your own use or for others
- Distribute the designs, modified or unmodified
- Use them commercially
- Repair, maintain, and reproduce hardware you own indefinitely

Institutions do not need a separate agreement with us to do any of the above.

## What is required in return

Under CERN-OHL-W, if you **distribute a product** based on a modified version of our design, you must make your modified design files available under the same license. Changes to the surrounding product — an instrument our board is embedded in — do **not** have to be published; only changes to our design itself.

Firmware is MIT-licensed: you may use and modify it freely, including in closed products, as long as the copyright notice is retained. There is no obligation to publish changes.

The host application is GPL-3.0: if you distribute a modified version, it must be under the same license with source available.

Under CC-BY-4.0, documentation requires attribution.

CERN-OHL also requires that a **Source Location** be discoverable — a place where the design files can be obtained. Our boards carry a reference to `github.com/GordonAnderson`.

## Trademarks

**Trademarks are not licensed by any of the above.** Copyright licenses do not grant trademark rights.

"GAA Custom Electronics," "GAACE," "MIPS," and "Astraea" are marks of GAA Custom Electronics, LLC.

You may accurately describe your work as based on, derived from, or compatible with a GAACE design. You may not use our names or logo to identify your product, in your product's branding, or in any manner that suggests we endorse, supplied, or support it.

This is how open hardware companies protect their identity while giving away their engineering. The designs are yours to use; the name is not.

## A request, not a requirement

If you are manufacturing our designs commercially, we'd appreciate hearing from you first. This carries no legal weight and you are free to ignore it — but we're a three-person shop that gave away its engineering, and a heads-up goes a long way.

## Data not yet published

Our hardware is being published progressively, starting with discrete components and working toward more complex systems. Not everything is up yet.

**If there's technical data you need that isn't here — a schematic for a board you're servicing, design files to base a variant on — contact us and we'll share it.** No NDA, no cost, no negotiation.

**gaa@gaa-ce.com** · 509.628.6851

## Custom and customer-funded work

Designs developed under a customer-funded contract belong to that customer and are not published here unless they've agreed. Where GAACE funds development itself — which we often do when the result would be useful to other researchers — the result is ours to publish, and generally will be.

## Questions

If your institution requires a specific license identifier for procurement or publication, or if something above doesn't fit your situation, contact us. We'd rather have the conversation than have you walk away.

Full context: [gaacustom.com/open-source.html](https://www.gaacustom.com/open-source.html)
