# <Product Name>

<One-sentence description of what it is and what it's for.>

Designed and manufactured by [GAA Custom Electronics, LLC](https://www.gaacustom.com) — Kennewick, Washington.

---

## Specifications

| | |
|---|---|
| <Parameter> | <Value> |
| <Parameter> | <Value> |
| <Parameter> | <Value> |

<Keep this to what someone needs in order to decide whether it fits their setup. Full detail belongs in the manual.>

---

## What's in this repository

| Path | Contents |
|---|---|
| `hardware/schematic/` | Schematics — PDF and native CAD |
| `hardware/pcb/` | Board layout source |
| `hardware/gerbers/` | Fabrication files as sent to the board house |
| `hardware/bom/` | Bill of materials with vendor part numbers |
| `docs/` | Operations manual |

<Delete any row you haven't populated. An empty folder listed in a table is worse than not listing it.>

---

## Buying vs. building

These are available assembled and tested from GAACE — see [gaacustom.com](https://www.gaacustom.com). For most labs that's the cheaper option: a one-off fabrication run costs more than a finished board, before you've spent any of your own time on it.

Build your own if you need a variant we don't offer, if procurement makes purchasing impractical, or if you'd simply rather. That's what these files are for.

---

## License

Hardware design files in this repository are licensed under the **CERN Open Hardware Licence Version 2 — Weakly Reciprocal** (`CERN-OHL-W-2.0`). Full text: [`LICENSE`](LICENSE).

Documentation in `docs/` is licensed under **Creative Commons Attribution 4.0 International** (`CC-BY-4.0`). Full text: [`LICENSE-DOCS`](LICENSE-DOCS).

In plain terms: you may study, modify, manufacture, and distribute these designs, including commercially. If you distribute a product based on a modified version of this design, you must make your modified design files available under the same license. Changes to the surrounding product — an instrument this board is part of — do not have to be published.

**Trademarks are not licensed.** "GAA Custom Electronics," "GAACE," "MIPS," and "Astraea" are marks of GAA Custom Electronics, LLC. You may accurately state that a board is based on our design. You may not use our names or logo to identify your product, or in any manner suggesting we endorse or supplied it.

**A request, not a requirement:** if you're manufacturing these designs commercially, we'd appreciate hearing from you first. We're a three-person shop that gave away its engineering, and a heads-up goes a long way.

---

## Contributing

Improvements, corrections, and documentation are welcome — see [`CONTRIBUTING.md`](CONTRIBUTING.md).

Found an error in a schematic, or a part that's gone obsolete? Open an issue. That's genuinely useful to us.

If you've built a variant other labs would find useful, we'd rather fold it in than have you maintain a private fork.

---

## Support

**gaa@gaa-ce.com** · 509.628.6851

If there's technical data you need that isn't published here, ask. We share it, and we don't require an NDA.

More about how and why we publish: [gaacustom.com/open-source.html](https://www.gaacustom.com/open-source.html)
