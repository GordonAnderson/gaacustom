# PCB KF Vacuum Feedthroughs

Printed-circuit-board vacuum feedthroughs for KF flanges — a low-cost alternative to machined feedthroughs for signal and low-voltage connections into a vacuum chamber.

Designed and manufactured by [GAA Custom Electronics, LLC](https://www.gaacustom.com) — Kennewick, Washington.

---

## Specifications

| | |
|---|---|
| Flange sizes | KF16, KF25, KF40 |
| Connector options | BNC, D9, Picoblade, pin header |
| Pressure tested to | 10⁻⁶ Torr |
| Board material | <FR4 / other — fill in> |
| Operating temperature | <fill in> |
| Max voltage | <fill in> |

Full detail in the [operations manual](docs/KF_Vacuum_Feedthroughs.pdf).

---

## What's in this repository

| Path | Contents |
|---|---|
| `hardware/schematic/` | Schematics — PDF and native CAD |
| `hardware/pcb/` | Board layout source |
| `hardware/gerbers/` | Fabrication files as sent to the board house |
| `hardware/bom/` | Bill of materials with vendor part numbers |
| `docs/` | Operations manual |

Separate design variants per flange size and connector type are under `hardware/`, named by flange and connector — e.g. `KF25-D9`.

---

## Buying vs. building

Assembled and tested feedthroughs are $35 each from GAACE — see [gaacustom.com/ion-optics.html](https://www.gaacustom.com/ion-optics.html). For most labs that's the cheaper route: a one-off fabrication run costs more than a finished part, before you've spent any of your own time on it.

Build your own if you need a flange size, connector, or pin count we don't offer, if procurement makes purchasing impractical, or if you'd simply rather. That's what these files are for.

---

## Notes on use

<Anything a builder needs to know that isn't obvious from the files — O-ring selection, torque, cleaning before installation, bakeout limits, what not to do. This section is where a published design becomes something someone can actually build successfully, and it's the part most open hardware projects skip.>

---

## License

Hardware design files in this repository are licensed under the **CERN Open Hardware Licence Version 2 — Weakly Reciprocal** (`CERN-OHL-W-2.0`). Full text: [`LICENSE`](LICENSE).

Documentation in `docs/` is licensed under **Creative Commons Attribution 4.0 International** (`CC-BY-4.0`). Full text: [`LICENSE-DOCS`](LICENSE-DOCS).

In plain terms: you may study, modify, manufacture, and distribute these designs, including commercially. If you distribute a product based on a modified version of this design, you must make your modified design files available under the same license. Changes to the surrounding product — an instrument this feedthrough is part of — do not have to be published.

**Trademarks are not licensed.** "GAA Custom Electronics," "GAACE," "MIPS," and "Astraea" are marks of GAA Custom Electronics, LLC. You may accurately state that a board is based on our design. You may not use our names or logo to identify your product, or in any manner suggesting we endorse or supplied it.

**A request, not a requirement:** if you're manufacturing these designs commercially, we'd appreciate hearing from you first. We're a three-person shop that gave away its engineering, and a heads-up goes a long way.

---

## Contributing

Improvements, corrections, and documentation are welcome — see [`CONTRIBUTING.md`](CONTRIBUTING.md).

Found an error in a schematic, or a part that's gone obsolete? Open an issue. That's genuinely useful to us.

If you've built a variant other labs would find useful — a flange size or connector we don't offer — we'd rather fold it in than have you maintain a private fork.

---

## Support

**gaa@gaa-ce.com** · 509.628.6851

If there's technical data you need that isn't published here, ask. We share it, and we don't require an NDA.

More about how and why we publish: [gaacustom.com/open-source.html](https://www.gaacustom.com/open-source.html)
