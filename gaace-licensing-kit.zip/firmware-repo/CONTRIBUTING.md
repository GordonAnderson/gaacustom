# Contributing

We're a three-person company building electronics for mass spectrometry labs. Contributions are genuinely welcome — most of what we make exists because a researcher told us what was missing.

## Reporting a problem

Open an issue. Useful things to include:

- What you were trying to do
- What happened instead
- Version or commit, and platform
- Console output or error text, if any

Errors in schematics, obsolete parts in a BOM, and unclear documentation are all worth reporting. We'd rather hear about it than have someone else hit the same thing.

## Suggesting something

If there's a piece of electronics standing between you and an experiment, describe it. Even if we don't build it, the conversation is free — and more than once, a question from one lab has become a product that a dozen others now use.

For anything substantial, email **gaa@gaa-ce.com** rather than opening an issue. Faster, and we can talk properly.

## Pull requests

Welcome — for bug fixes, features, documentation, and drivers.

A few practical notes:

- **Open an issue first** for anything large, so we can agree on the approach before you spend time on it
- **Match the existing code style.** No reformatting commits mixed in with functional changes.
- **Explain the why**, not just the what.
- **Say what you tested it against** — which hardware, which platform.

By submitting a contribution you agree it may be distributed under the same license as the rest of the repository — MIT — **or under any later version of that license, or any other license we may adopt for this project in the future.**

That last clause matters more than it looks. Once a project has contributions from several people, relicensing requires permission from every one of them, and open source is full of projects that got stuck because a contributor became unreachable. Agreeing to it up front means the project can move to a newer license version later without tracking everyone down. It does not let us take your contribution proprietary — anything already published under an open license stays available under that license permanently.

## Sign-off (DCO)

We use the [Developer Certificate of Origin](https://developercertificate.org/) — a lightweight statement that you have the right to submit what you're submitting. No forms, no account, no paperwork.

Add a sign-off line to each commit:

```
Signed-off-by: Jane Researcher <jane@university.edu>
```

Git will add it for you with the `-s` flag:

```
git commit -s -m "Fix serial timeout on Linux hosts"
```

Use your real name and a real email address. By signing off, you certify that:

- you created the contribution yourself, or
- you have the right to submit it under the project's license — for example, it's based on work under a compatible license, or your employer or institution permits it

**If you're contributing as part of your job or academic position, check who owns your work before you submit.** Many universities and companies claim ownership of work done by employees or students. We'd rather you sort that out beforehand than have a contribution unwound later.

If you forget the sign-off, no problem — we'll ask, and `git commit --amend -s` fixes it.

## Variants and forks

If you've written a control panel, scripting module, or driver other labs would find useful, we'd rather fold it into the mainline — or link to it from the README — than have you maintain a private fork forever. Get in touch.

## What we can't merge

Occasionally a change is right for one lab but wrong as a default. If we decline something we'll say why, and you're free to maintain it as a fork. That's what the license is for.
