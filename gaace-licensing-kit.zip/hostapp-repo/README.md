# <Repository Name>

<One-sentence description. e.g. "Cross-platform Qt host application unifying every MIPS controller and GAACE instrument under one interface.">

Developed by [GAA Custom Electronics, LLC](https://www.gaacustom.com) — Kennewick, Washington.

---

## Building

**Requirements:** <toolchain, versions, dependencies>

```
<build commands>
```

Tested on <platforms>.

---

## What's in this repository

| Path | Contents |
|---|---|
| `src/` | Application source |
| `docs/` | Manual, scripting examples |

---

## <Scripting / custom panels / extending>

<If this project supports user scripting or custom control panels, describe it here. This is often the main reason someone clones the source rather than downloading a binary — worth more than a sentence.>

---

## License

Licensed under the **GNU General Public License v3.0 or later** (`GPL-3.0-or-later`). Full text: [`LICENSE`](LICENSE).

You may use, study, modify, and redistribute this software. If you distribute a modified version, it must be under the same license with source available.

**Trademarks are not licensed.** "GAA Custom Electronics," "GAACE," "MIPS," and "Astraea" are marks of GAA Custom Electronics, LLC. You may state that your software is based on ours. You may not use our names to identify your product or imply endorsement.

### Third-party components

<REQUIRED — complete this section. List every bundled library, vendor HAL, and framework, with its license.>

<If this application links against open-source Qt, that is LGPLv3 and carries obligations around dynamic linking and relinkability. State it here explicitly. This is the item an institution's legal office is most likely to ask about.>

| Component | Version | License |
|---|---|---|
| <name> | <version> | <license> |

---

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Pull requests welcome — if you've written a control panel, scripting module, or driver that other labs would use, we'd rather merge it than have you maintain a fork indefinitely.

---

## Support

**gaa@gaa-ce.com** · 509.628.6851

More about how and why we publish: [gaacustom.com/open-source.html](https://www.gaacustom.com/open-source.html)
