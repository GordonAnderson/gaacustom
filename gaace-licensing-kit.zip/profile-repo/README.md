## Gordon Anderson — GAA Custom Electronics, LLC

Custom electronics for mass spectrometry and ion optics research. Kennewick, Washington — since 2014.

We build modular control systems, RF and DC drivers, waveform generators, and PCB-level ion optics for university labs, national laboratories, and instrument developers. Deployed in 200+ systems across 16+ countries.

**[gaacustom.com](https://www.gaacustom.com)** · gaa@gaa-ce.com · [Publications](https://scholar.google.com/citations?hl=en&user=u2xMtMgAAAAJ&view_op=list_works&sortby=pubdate)

---

### Why these repositories exist

Research instruments outlive their documentation. A source built for ion mobility ends up on a TOF; a control sequence written for one experiment becomes the backbone of a thesis three years later. When that happens you need to know what the hardware actually does, not what a datasheet claims.

Published methods that depend on a black-box controller can't be independently reproduced. And we're a small company — if we ever cease operation, our customers shouldn't be left with an unmaintainable instrument.

So: our firmware and host software have been public here since the start, and we're now extending that to hardware. Schematics, board files, parts lists, and Gerbers, beginning with discrete components and working toward full systems. It's a work in progress.

**If there's technical data you need that isn't published yet — a schematic for a board you're troubleshooting, design files to base a variant on — just ask.** We share it, and we don't require an NDA.

More on the approach: **[gaacustom.com/open-source.html](https://www.gaacustom.com/open-source.html)**

---

### Licensing — unless otherwise noted

Each repository carries its own `LICENSE` file, which governs. Where a repository doesn't state otherwise, our defaults are:

| | License | SPDX |
|---|---|---|
| Hardware design files | CERN Open Hardware Licence v2 — Weakly Reciprocal | `CERN-OHL-W-2.0` |
| Firmware (runs on our boards) | MIT License | `MIT` |
| Host application / portable software | GNU General Public License v3.0 or later | `GPL-3.0-or-later` |
| Documentation and manuals | Creative Commons Attribution 4.0 | `CC-BY-4.0` |

You may study, modify, manufacture, and distribute these designs — including commercially — provided modified design files are made available under the same terms.

**Trademarks are not licensed.** "GAA Custom Electronics," "GAACE," "MIPS," and "Astraea" are marks of GAA Custom Electronics, LLC. You may accurately state that your work is based on our design. You may not use our names or logo to identify your product, or in any way suggesting we endorse or supplied it.

If your institution needs a specific license identifier for procurement or publication purposes and something here doesn't fit, get in touch — we'd rather have that conversation than have you quietly walk away.

**A request, not a requirement:** if you're manufacturing our designs commercially, we'd appreciate hearing from you first.

---

### Contributing

Bug reports, corrections, and pull requests are welcome across all repositories. Errors in a schematic, an obsolete part in a BOM, unclear documentation — all worth reporting.

If you've built a variant, written a control panel, or produced documentation other labs would benefit from, we'd rather fold it in than have you maintain a private fork.
