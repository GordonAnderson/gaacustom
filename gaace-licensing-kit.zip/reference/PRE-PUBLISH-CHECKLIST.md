# Pre-Publish Checklist

Work through this once, before the first repository goes public. Most items are one-time.

---

## Blocking — resolve before anything is published

- [ ] **Customer-funded designs.** Anything developed under a customer-funded contract may belong to that customer, not to GAACE. The rate sheet already distinguishes GAACE-funded work (which becomes a sellable product) from customer-funded proprietary work. Apply that line to every design before its repo goes public. When in doubt, ask the customer — a short email is cheaper than retracting a published design.

- [ ] **Reconcile the rate sheet.** `RateSheet03292026.docx` currently states that product IP is "nontransferable" and cannot be "duplicated, transferred and/or re-sold." That directly contradicts an open hardware license. Either scope that clause explicitly to customer-funded proprietary work, or update it. As written, a customer could reasonably point at it and say the published license doesn't mean what it says.

- [ ] **Third-party libraries in firmware (MIT repo).** Every Arduino library, vendor HAL, and datasheet-example snippet has its own license. MIT is compatible with permissive licenses (MIT, BSD, Apache, LGPL). Watch specifically for any **GPL-licensed** dependency — bundling one imposes copyleft on the combined distribution, which defeats the point of choosing MIT. Remove, replace, or isolate it.

- [ ] **Qt licensing for the host application (GPL repo).** If `MIPS_QT6` links against open-source Qt, that is LGPLv3 and carries real obligations — most notably that users must be able to relink against a modified Qt. GPL-3.0 on your own code is compatible with this, but compliance is a separate question from your license choice, and it's worth confirming independently. This is the single item most likely to be raised by an institution's legal office.

---

## Before the first hardware repo

- [ ] **Decide the folder structure and stick to it.** Whatever the feedthrough repo uses becomes the template for every release after. `hardware/schematic/`, `hardware/pcb/`, `hardware/gerbers/`, `hardware/bom/`, `docs/` is a reasonable default.

- [ ] **Decide the revision naming convention.** How a board revision appears in folder names, file names, and the README. Retrofitting this across a dozen repos is painful.

- [ ] **Decide what "native CAD" means here.** Which tool, which version, and whether you'll also publish a neutral export for people who don't have it.

- [ ] **Add the Source Location notice** to the schematic title block and, where space allows, the silkscreen. See `SOURCE-LOCATION-NOTICE.txt`. CERN-OHL requires that recipients can find the source.

- [ ] **Check the BOM for anything you'd rather not disclose** — a supplier you'd prefer not to name, an internal part number that maps to something confidential. Rare, but worth one pass.

---

## Trademark

- [ ] **Consider filing for "MIPS" and "Astraea."** Trademark, not copyright, is what stops someone selling a clone under your name. It is also what makes open licensing safe: the designs are free, the brand isn't. Unregistered common-law marks give you something, but registration gives you considerably more.

- [ ] Note that "MIPS" is also a well-known processor architecture trademark held by another company. In your field and product category the conflict is unlikely to matter, but it's worth a conversation with an attorney before filing.

---

## SBIR / STTR

- [ ] **Keep published designs cleanly delineated from SBIR-funded deliverables.** SBIR data rights are a separate legal regime with their own protection periods. Entangling published open designs with SBIR deliverables is difficult to undo, and the time to think about it is before a proposal, not after an award.

---

## Website and announcement

- [ ] Add a **"What's published so far"** list to `open-source.html`, updated as designs go up. This is what makes progress visible now that there's deliberately no target date.

- [ ] Update the licensing language in `open-source.html`'s Terms section to name the actual licenses and SPDX identifiers, replacing the current "we ask that you don't manufacture for commercial resale" framing — which is no longer accurate once the designs are genuinely open.

- [ ] Only then post to LinkedIn. An interested reader's first action is clicking through to GitHub.
